﻿using System.IO;

namespace UCS.PacketProcessing
{
    internal class CancelShieldCommand : Command
    {
        public CancelShieldCommand(BinaryReader br) { }
    }
}