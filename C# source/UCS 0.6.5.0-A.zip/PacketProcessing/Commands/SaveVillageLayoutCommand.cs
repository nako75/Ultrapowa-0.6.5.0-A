﻿using System.IO;

namespace UCS.PacketProcessing
{
    internal class SaveVillageLayoutCommand : Command
    {
        public SaveVillageLayoutCommand(BinaryReader br) { }
    }
}