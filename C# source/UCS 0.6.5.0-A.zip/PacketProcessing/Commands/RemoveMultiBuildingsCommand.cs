﻿using System.IO;

namespace UCS.PacketProcessing
{
    internal class RemoveMultiBuildingsCommand : Command
    {
        public RemoveMultiBuildingsCommand(BinaryReader br) { }
    }
}