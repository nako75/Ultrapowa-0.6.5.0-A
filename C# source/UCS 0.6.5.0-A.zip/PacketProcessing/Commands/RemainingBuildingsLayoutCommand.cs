﻿using System.IO;

namespace UCS.PacketProcessing
{
    internal class RemainingBuildingsLayoutCommand : Command
    {
        public RemainingBuildingsLayoutCommand(BinaryReader br) { }
    }
}