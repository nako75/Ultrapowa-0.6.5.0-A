﻿using System.IO;

namespace UCS.PacketProcessing
{
    internal class EditVillageLayoutCommand : Command
    {
        public EditVillageLayoutCommand(BinaryReader br) { }
    }
}