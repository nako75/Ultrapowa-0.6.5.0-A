﻿using System.IO;

namespace UCS.PacketProcessing
{
    internal class FilterChatCommand : Command
    {
        public FilterChatCommand(BinaryReader br) { }
    }
}