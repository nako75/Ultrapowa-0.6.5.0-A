﻿namespace UCS.Logic
{
    internal class HitpointComponent : Component
    {
        private const int m_vType = 0x01AB3F00;

        public override int Type
        {
            get { return 2; }
        }
    }
}